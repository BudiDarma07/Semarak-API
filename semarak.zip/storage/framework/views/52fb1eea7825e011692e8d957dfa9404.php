

<?php $__env->startSection('content'); ?>
<div class="bg-white p-6 rounded-lg shadow-md">
    <h1 class="text-xl font-semibold text-gray-800 mb-6">Tambah Data Aset</h1>
    <form action="<?php echo e(route('aset.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="grid grid-cols-1 gap-6">
            <div>
                <label for="kode_aset" class="block text-sm font-semibold text-gray-700">Kode Aset</label>
                <input type="text" name="kode_aset" id="kode_aset" value="<?php echo e(old('kode_aset')); ?>" class="py-2 px-3 mt-1 block w-full border-gray-300 rounded-md border focus:outline-none focus:ring-blue-500 focus:border-blue-500" required>
                <?php $__errorArgs = ['kode_aset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="nama_aset" class="block text-sm font-semibold text-gray-700">Nama Aset</label>
                <input type="text" name="nama_aset" id="nama_aset" value="<?php echo e(old('nama_aset')); ?>" class="py-2 px-3 mt-1 block w-full border-gray-300 rounded-md border focus:outline-none focus:ring-blue-500 focus:border-blue-500" required>
                <?php $__errorArgs = ['nama_aset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="kategori_id" class="block text-sm font-semibold text-gray-700">Kategori</label>
                <select name="kategori_id" id="kategori_id" class="py-2 px-3 mt-1 block w-full border-gray-300 rounded-md border focus:outline-none focus:ring-blue-500 focus:border-blue-500" required>
                    <option hidden value="">Pilih Kategori</option>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kategori->id_kategori); ?>"><?php echo e($kategori->nama_kategori); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['kategori_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="lokasi" class="block text-sm font-semibold text-gray-700">Lokasi</label>
                <input type="text" name="lokasi" id="lokasi" value="<?php echo e(old('lokasi')); ?>" class="py-2 px-3 mt-1 block w-full border-gray-300 rounded-md border focus:outline-none focus:ring-blue-500 focus:border-blue-500" required>
                <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="flex justify-end space-x-2 mt-6">
            <a href="<?php echo e(route('aset.index')); ?>" class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg">Batal</a>
            <button type="submit" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg">Simpan</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\semarak-app\resources\views/aset/create.blade.php ENDPATH**/ ?>