

<?php $__env->startSection('content'); ?>

<div class="bg-white rounded-lg shadow-md p-3">
    
    <div class="flex items-center justify-between pb-3 border-b">
        <h1 class="text-xl font-semibold text-gray-800">
            <?php echo e($laporan->tipe_laporan == 'pemeliharaan' ? 'Laporan Pemeliharaan' : 'Laporan Tindak Lanjut'); ?>

        </h1>
        <div class="flex items-center space-x-2">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-laporan')): ?>
                <form action="<?php echo e(route('laporan.destroy', $laporan)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus laporan ini? Ini tidak bisa dibatalkan.');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="px-4 py-2 bg-red-600 text-white text-sm font-medium rounded-lg hover:bg-red-700">
                        Hapus
                    </button>
                </form>
            <?php endif; ?>
            <a href="<?php echo e(url()->previous()); ?>" class="px-4 py-2 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700">
                Kembali
            </a>
        </div>
    </div>

    <div class="w-full h-1.5 <?php echo e($laporan->tipe_laporan == 'pemeliharaan' ? 'bg-green-500' : 'bg-red-500'); ?> rounded-b-md"></div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 mt-4 text-base">
        <div>
            <label class="block text-gray-500 mb-1">Tanggal Laporan</label>
            <p class="font-semibold text-gray-800 px-3 py-2 border border-gray-300 rounded-md"><?php echo e($laporan->created_at->format('d F Y')); ?></p>
        </div>

        <?php if($laporan->tipe_laporan == 'tindak_lanjut'): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-status-laporan')): ?>
                <div>
                    <form action="<?php echo e(route('laporan.updateStatus', $laporan)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <label for="status" class="block text-gray-500 mb-1">Ubah Status</label>
                        <div class="flex items-center space-x-2">
                            <select name="status" id="status" class="border rounded-md text-sm w-full px-3 py-2 focus:outline-none focus:ring-1 focus:ring-blue-500">
                                <option value="Belum Proses" <?php if($laporan->status == 'Belum Proses'): ?> selected <?php endif; ?>>Belum Proses</option>
                                <option value="Selesai" <?php if($laporan->status == 'Selesai'): ?> selected <?php endif; ?>>Selesai</option>
                            </select>
                            <button type="submit" class="px-3 py-2 bg-blue-600 text-white text-xs font-semibold rounded-lg hover:bg-blue-700">Update</button>
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <div>
                    <label class="block text-gray-500 mb-1">Status</label>
                    <p class="font-semibold text-gray-800 px-3 py-2 border border-gray-300 rounded-md"><?php echo e($laporan->status); ?></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <div>
            <label class="block text-gray-500 mb-1">Nama Aset</label>
            <p class="font-semibold text-gray-800 px-3 py-2 border border-gray-300 rounded-md"><?php echo e($laporan->aset->nama_aset); ?></p>
        </div>
        <div>
            <label class="block text-gray-500 mb-1">Nama Teknisi</label>
            <p class="font-semibold text-gray-800 px-3 py-2 border border-gray-300 rounded-md"><?php echo e($laporan->nama_teknisi); ?></p>
        </div>
        <div>
            <label class="block text-gray-500 mb-1">Lokasi</label>
            <p class="font-semibold text-gray-800 px-3 py-2 border border-gray-300 rounded-md"><?php echo e($laporan->aset->lokasi); ?></p>
        </div>
        <div>
            <label class="block text-gray-500 mb-1">Kategori</label>
            <p class="font-semibold text-gray-800 px-3 py-2 border border-gray-300 rounded-md"><?php echo e($laporan->aset->kategori->nama_kategori ?? 'N/A'); ?></p>
        </div>
    </div>

    <div class="mt-6">
        <?php
            // Memisahkan pertanyaan "Catatan" dari pertanyaan checklist lainnya
            $pertanyaanCatatan = $laporan->jawabans->first(function ($jawaban) {
                return Str::contains(strtolower($jawaban->pertanyaan->pertanyaan), 'catatan');
            });
            $pertanyaanChecklist = $laporan->jawabans->reject(function ($jawaban) {
                return Str::contains(strtolower($jawaban->pertanyaan->pertanyaan), 'catatan');
            });
        ?>

        <h3 class="text-base font-semibold text-gray-800 mb-2">
            <?php echo e($laporan->tipe_laporan == 'pemeliharaan' ? 'Pertanyaan Pemeliharaan' : 'Pertanyaan Tindak Lanjut'); ?>

        </h3>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 text-sm border-t pt-4">
            <?php $__empty_1 = true; $__currentLoopData = $pertanyaanChecklist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex justify-between">
                    <span class="text-gray-700"><?php echo e($jawaban->pertanyaan->pertanyaan); ?></span>
                    <span class="font-semibold text-gray-800"><?php echo e($jawaban->jawaban); ?></span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-500 col-span-2">Tidak ada data checklist.</p>
            <?php endif; ?>
        </div>

        <?php if($pertanyaanCatatan): ?>
            <div class="mt-6">
                 <h3 class="text-base font-semibold text-gray-800 mb-2"><?php echo e($pertanyaanCatatan->pertanyaan->pertanyaan); ?></h3>
                 <div class="w-full p-3 bg-gray-50 border rounded-md text-sm text-gray-700">
                    <?php echo e($pertanyaanCatatan->jawaban); ?>

                 </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if($laporan->dokumentasis->count() > 0): ?>
        <div class="mt-6">
            <h3 class="text-base font-bold text-gray-800 mb-2">Dokumentasi</h3>
            <div class="border rounded-md p-3 space-y-3">
                <?php $__currentLoopData = $laporan->dokumentasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        // Memecah 'laporan_dokumentasi/namafile.jpg' menjadi folder dan nama file
                        $pathParts = explode('/', $doc->file_path);
                        $folder = $pathParts[0];
                        $filename = $pathParts[1];
                    ?>
                    <div class="flex items-center justify-between text-sm bg-gray-50 p-2 rounded-md">
                        
                        <a href="<?php echo e(asset('storage/' . $doc->file_path)); ?>" target="_blank" class="flex items-center text-gray-700 hover:text-blue-600 truncate">
                            <svg class="w-5 h-5 mr-2 flex-shrink-0 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                            <span class="truncate"><?php echo e($doc->file_name); ?></span>
                        </a>

                        
                        <a href="<?php echo e(asset('storage/' . $doc->file_path)); ?>" 
                           download="<?php echo e($doc->file_name); ?>"
                           class="ml-4 flex-shrink-0 px-3 py-1 bg-blue-600 text-white font-medium text-sm rounded-md hover:bg-blue-700 transition">
                           Download
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\semarak-app\resources\views/laporan/show.blade.php ENDPATH**/ ?>